import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        System.out.println("Ingrese 2 para saber tu resultado de calificacion");
        Scanner sc = new Scanner(System.in);
        int cantidad = sc.nextInt();
        if (cantidad == 2) {

            System.out.println("tu calificacion es muy mala es mejor que no sepas");
            String edad = sc.next();







        }

    }
}